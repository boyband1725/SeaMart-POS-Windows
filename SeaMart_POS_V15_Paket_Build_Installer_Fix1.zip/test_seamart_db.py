"""Smoke tests for SeaMart POS V15 database schema and stock-opname integrity."""
import importlib.util
import os
import tempfile
import unittest


class SeaMartDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.home = tempfile.mkdtemp(prefix="seamart-v15-test-")
        os.environ["HOME"] = self.home
        os.environ.pop("LOCALAPPDATA", None)
        spec = importlib.util.spec_from_file_location("seamart_under_test", "seamart.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)

    def test_fresh_database_schema(self):
        self.app.init()
        with self.app.db() as conn:
            products = {r["name"] for r in conn.execute("PRAGMA table_info(products)")}
            items = {r["name"] for r in conn.execute("PRAGMA table_info(sale_items)")}
            moves = {r["name"] for r in conn.execute("PRAGMA table_info(movements)")}
        self.assertIn("min_stock", products)
        self.assertIn("cost", items)
        self.assertTrue({"stock_before", "stock_after"}.issubset(moves))

    def test_migrate_older_database(self):
        os.makedirs(self.app.DATA_ROOT, exist_ok=True)
        import sqlite3
        conn = sqlite3.connect(self.app.DB)
        conn.executescript("""
            CREATE TABLE groups(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
            CREATE TABLE products(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL,
                barcode TEXT UNIQUE, name TEXT NOT NULL, group_id INTEGER,
                cost REAL DEFAULT 0, price REAL DEFAULT 0, stock REAL DEFAULT 0,
                active INTEGER DEFAULT 1);
            CREATE TABLE sales(id INTEGER PRIMARY KEY, invoice TEXT UNIQUE, created TEXT,
                payment TEXT, subtotal REAL, discount REAL, total REAL, received REAL,
                change_due REAL, status TEXT DEFAULT 'PROCESSED');
            CREATE TABLE sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER, product_id INTEGER,
                code TEXT, barcode TEXT, name TEXT, qty REAL, price REAL,
                discount REAL, line_total REAL);
            CREATE TABLE movements(id INTEGER PRIMARY KEY, created TEXT, product_id INTEGER,
                kind TEXT, qty REAL, note TEXT, ref TEXT);
            CREATE TABLE cash_entries(id INTEGER PRIMARY KEY, created TEXT, kind TEXT,
                description TEXT, amount REAL, ref TEXT);
            CREATE TABLE audit(id INTEGER PRIMARY KEY, created TEXT, action TEXT, detail TEXT);
        """)
        conn.commit()
        conn.close()
        self.app.init()
        with self.app.db() as conn:
            self.assertIn("min_stock", {r["name"] for r in conn.execute("PRAGMA table_info(products)")})
            self.assertIn("cost", {r["name"] for r in conn.execute("PRAGMA table_info(sale_items)")})
            self.assertTrue({"stock_before", "stock_after"}.issubset(
                {r["name"] for r in conn.execute("PRAGMA table_info(movements)")}))

    def test_stock_opname_updates_stock_and_audit_atomically(self):
        self.app.init()
        with self.app.db() as conn:
            group_id = conn.execute("SELECT id FROM groups WHERE name='Makanan'").fetchone()[0]
            conn.execute("""INSERT INTO products(code,name,group_id,stock,min_stock,cost,price)
                VALUES(?,?,?,?,?,?,?)""", ("TEST-001", "Barang Uji", group_id, 50, 5, 1000, 2000))
            product_id = conn.execute("SELECT id FROM products WHERE code='TEST-001'").fetchone()[0]
        with self.app.db() as conn:
            conn.execute("BEGIN IMMEDIATE")
            before = conn.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
            after = 45
            delta = after - before
            conn.execute("UPDATE products SET stock=? WHERE id=?", (after, product_id))
            conn.execute("""INSERT INTO movements(created,product_id,kind,qty,note,ref,stock_before,stock_after)
                VALUES(?,?,?,?,?,?,?,?)""", ("2026-11-09T02:00:00", product_id,
                "PENYESUAIAN", delta, "Stok opname uji", "OPNAME-TEST", before, after))
            conn.execute("INSERT INTO audit(created,action,detail) VALUES(?,?,?)",
                ("2026-11-09T02:00:00", "PENYESUAIAN STOK", "uji integritas"))
        with self.app.db() as conn:
            stock = conn.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
            movement = conn.execute("SELECT qty,stock_before,stock_after FROM movements WHERE ref='OPNAME-TEST'").fetchone()
            audit_count = conn.execute("SELECT COUNT(*) FROM audit WHERE action='PENYESUAIAN STOK'").fetchone()[0]
        self.assertEqual(stock, 45)
        self.assertEqual(tuple(movement), (-5, 50, 45))
        self.assertEqual(audit_count, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
