import sqlite3, csv, os, sys, shutil
from contextlib import contextmanager
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

APP = "SeaMart POS V15"
# Keep the database in a writable per-user folder. A one-file EXE installed
# under Program Files must not try to write beside the executable.
if os.name == "nt":
    DATA_ROOT = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "SeaMartPOS")
else:
    DATA_ROOT = os.path.join(os.path.expanduser("~"), ".seamartpos")
os.makedirs(DATA_ROOT, exist_ok=True)
DB = os.path.join(DATA_ROOT, "seamart.db")

@contextmanager
def db():
    """Open a short-lived SQLite connection and always close it."""
    c = sqlite3.connect(DB, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()

def init():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS groups(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, barcode TEXT UNIQUE,
          name TEXT NOT NULL, group_id INTEGER, cost REAL DEFAULT 0,
          price REAL DEFAULT 0, stock REAL DEFAULT 0, min_stock REAL DEFAULT 0, active INTEGER DEFAULT 1,
          FOREIGN KEY(group_id) REFERENCES groups(id));
        CREATE TABLE IF NOT EXISTS sales(
          id INTEGER PRIMARY KEY, invoice TEXT UNIQUE, created TEXT, payment TEXT,
          subtotal REAL, discount REAL, total REAL, received REAL, change_due REAL,
          status TEXT DEFAULT 'PROCESSED');
        CREATE TABLE IF NOT EXISTS sale_items(
          id INTEGER PRIMARY KEY, sale_id INTEGER, product_id INTEGER,
          code TEXT, barcode TEXT, name TEXT, qty REAL, price REAL,
          cost REAL DEFAULT 0, discount REAL, line_total REAL,
          FOREIGN KEY(sale_id) REFERENCES sales(id));
        CREATE TABLE IF NOT EXISTS movements(
          id INTEGER PRIMARY KEY, created TEXT, product_id INTEGER,
          kind TEXT, qty REAL, note TEXT, ref TEXT,
          stock_before REAL, stock_after REAL);
        CREATE TABLE IF NOT EXISTS cash_entries(
          id INTEGER PRIMARY KEY, created TEXT NOT NULL, kind TEXT NOT NULL,
          description TEXT NOT NULL, amount REAL NOT NULL, ref TEXT);
        CREATE TABLE IF NOT EXISTS audit(
          id INTEGER PRIMARY KEY, created TEXT, action TEXT, detail TEXT);
        """)
        # Safe schema upgrades for databases created by earlier V15 builds.
        product_cols={r["name"] for r in c.execute("PRAGMA table_info(products)")}
        if "min_stock" not in product_cols:
            c.execute("ALTER TABLE products ADD COLUMN min_stock REAL DEFAULT 0")
        item_cols={r["name"] for r in c.execute("PRAGMA table_info(sale_items)")}
        if "cost" not in item_cols:
            c.execute("ALTER TABLE sale_items ADD COLUMN cost REAL DEFAULT 0")
        movement_cols={r["name"] for r in c.execute("PRAGMA table_info(movements)")}
        if "stock_before" not in movement_cols:
            c.execute("ALTER TABLE movements ADD COLUMN stock_before REAL")
        if "stock_after" not in movement_cols:
            c.execute("ALTER TABLE movements ADD COLUMN stock_after REAL")
        for g in ["Makanan","Minuman","Sembako","Rokok","Perlengkapan Rumah Tangga","Kosmetik","Lain-lain"]:
            c.execute("INSERT OR IGNORE INTO groups(name) VALUES(?)",(g,))

def audit(action, detail):
    with db() as c: c.execute("INSERT INTO audit(created,action,detail) VALUES(?,?,?)",(datetime.now().isoformat(timespec="seconds"),action,detail))

class SeaMart:
    def __init__(self, root):
        self.root=root; root.title(APP); root.geometry("1200x760"); root.minsize(1000,650)
        root.configure(bg="#eef2f7"); self.cart=[]; self.discount=0
        self.style=ttk.Style(); self.style.theme_use("clam")
        self.style.configure("Treeview", rowheight=28, font=("Segoe UI",10))
        self.style.configure("Treeview.Heading", font=("Segoe UI",10,"bold"))
        self.header=tk.Frame(root,bg="#102b50",height=65); self.header.pack(fill="x")
        tk.Label(self.header,text="S",font=("Segoe UI",25,"bold"),fg="white",bg="#102b50").pack(side="left",padx=20)
        tk.Label(self.header,text="SeaMart POS V15",font=("Segoe UI",19,"bold"),fg="white",bg="#102b50").pack(side="left")
        tk.Label(self.header,text="OFFLINE • WINDOWS 10 / 11",font=("Segoe UI",9),fg="#c9d8ea",bg="#102b50").pack(side="right",padx=20)
        self.tabs=ttk.Notebook(root); self.tabs.pack(fill="both",expand=True,padx=12,pady=12)
        self.cash=tk.Frame(self.tabs,bg="#eef2f7"); self.master=tk.Frame(self.tabs,bg="#eef2f7")
        self.report=tk.Frame(self.tabs,bg="#eef2f7"); self.cashbook=tk.Frame(self.tabs,bg="#eef2f7"); self.stocktab=tk.Frame(self.tabs,bg="#eef2f7")
        self.tabs.add(self.cash,text="  KASIR  "); self.tabs.add(self.master,text="  MASTER BARANG  "); self.tabs.add(self.report,text="  LAPORAN  "); self.tabs.add(self.cashbook,text="  KAS MASUK/KELUAR  "); self.tabs.add(self.stocktab,text="  STOK & MUTASI  ")
        self.build_cash(); self.build_master(); self.build_report(); self.build_cashbook(); self.build_stock(); self.refresh_products(); self.refresh_groups(); self.refresh_sales(); self.refresh_cashbook(); self.refresh_movements()
    def field(self,parent,label,var,width=18):
        box=tk.Frame(parent,bg=parent.cget("bg")); box.pack(side="left",padx=5)
        tk.Label(box,text=label,bg=parent.cget("bg"),fg="#25364b").pack(anchor="w")
        e=ttk.Entry(box,textvariable=var,width=width); e.pack(); return e
    def build_cash(self):
        top=tk.Frame(self.cash,bg="#eef2f7"); top.pack(fill="x",pady=10)
        self.search=tk.StringVar(); e=self.field(top,"Kode / Barcode / Nama Barang",self.search,34); e.bind("<Return>",lambda x:self.add_product())
        ttk.Button(top,text="Tambah",command=self.add_product).pack(side="left",padx=8,pady=16)
        self.group_filter=tk.StringVar(value="Semua Kelompok")
        self.group_combo=ttk.Combobox(top,textvariable=self.group_filter,state="readonly",width=22); self.group_combo.pack(side="right",padx=10,pady=16)
        cols=("code","barcode","name","qty","price","discount","total")
        self.cart_tree=ttk.Treeview(self.cash,columns=cols,show="headings",height=13)
        heads=["Kode Barang","Barcode","Nama Barang","Qty","Harga","Diskon","Subtotal"]
        widths=[110,130,300,65,110,90,120]
        for col,h,w in zip(cols,heads,widths): self.cart_tree.heading(col,text=h); self.cart_tree.column(col,width=w,anchor="w" if col=="name" else "center")
        self.cart_tree.pack(fill="both",expand=True,pady=8)
        row=tk.Frame(self.cash,bg="#eef2f7"); row.pack(fill="x",pady=5)
        ttk.Button(row,text="Ubah Qty",command=self.change_qty).pack(side="left",padx=4)
        ttk.Button(row,text="Diskon Barang",command=self.item_discount).pack(side="left",padx=4)
        ttk.Button(row,text="Hapus Item",command=self.remove_item).pack(side="left",padx=4)
        ttk.Button(row,text="BATAL / Kosongkan",command=self.clear_cart).pack(side="left",padx=4)
        pay=tk.Frame(self.cash,bg="white",padx=15,pady=10); pay.pack(fill="x",pady=8)
        self.total_label=tk.Label(pay,text="TOTAL: Rp 0",font=("Segoe UI",20,"bold"),fg="#102b50",bg="white"); self.total_label.pack(side="left")
        self.payment=tk.StringVar(value="Tunai"); ttk.Label(pay,text="Pembayaran").pack(side="left",padx=(30,5))
        ttk.Combobox(pay,textvariable=self.payment,values=["Tunai","QRIS"],state="readonly",width=10).pack(side="left")
        self.received=tk.StringVar(value="0"); self.field(pay,"Uang diterima",self.received,14)
        ttk.Button(pay,text="PROSES BAYAR",command=self.process_sale).pack(side="right",padx=10)
    def build_master(self):
        bar=tk.Frame(self.master,bg="#eef2f7"); bar.pack(fill="x",pady=10)
        ttk.Button(bar,text="Impor CSV",command=self.import_csv).pack(side="left",padx=4)
        ttk.Button(bar,text="Tambah Barang",command=self.add_dialog).pack(side="left",padx=4)
        ttk.Button(bar,text="Ubah",command=self.edit_product).pack(side="left",padx=4)
        ttk.Button(bar,text="Hapus",command=self.delete_product).pack(side="left",padx=4)
        ttk.Button(bar,text="Ekspor Excel/CSV",command=self.export_products).pack(side="left",padx=4)
        ttk.Button(bar,text="Kelompok Barang",command=self.add_group).pack(side="left",padx=4)
        self.product_tree=ttk.Treeview(self.master,columns=("code","barcode","name","group","cost","price","stock"),show="headings")
        for col,h,w in zip(("code","barcode","name","group","cost","price","stock"),["Kode","Barcode","Nama Barang","Kelompok","Modal","Harga Jual","Stok"],[110,130,280,180,100,110,80]):
            self.product_tree.heading(col,text=h); self.product_tree.column(col,width=w)
        self.product_tree.pack(fill="both",expand=True)
    def build_report(self):
        bar=tk.Frame(self.report,bg="#eef2f7"); bar.pack(fill="x",pady=10)
        ttk.Button(bar,text="Muat Ulang",command=self.refresh_sales).pack(side="left",padx=4)
        ttk.Button(bar,text="Ekspor Riwayat CSV",command=self.export_sales).pack(side="left",padx=4)
        ttk.Button(bar,text="Laporan per Barang",command=self.show_item_report).pack(side="left",padx=4)
        ttk.Button(bar,text="Ekspor Excel",command=self.export_xlsx).pack(side="left",padx=4)
        ttk.Button(bar,text="Ekspor PDF",command=self.export_pdf).pack(side="left",padx=4)
        ttk.Button(bar,text="UNPROSES Transaksi",command=self.unprocess).pack(side="left",padx=4)
        self.sales_tree=ttk.Treeview(self.report,columns=("invoice","date","payment","total","status"),show="headings")
        for col,h,w in zip(("invoice","date","payment","total","status"),["No. Transaksi","Tanggal","Pembayaran","Total","Status"],[190,220,120,150,120]):
            self.sales_tree.heading(col,text=h); self.sales_tree.column(col,width=w)
        self.sales_tree.pack(fill="both",expand=True)
        self.summary=tk.Label(self.report,text="",font=("Segoe UI",14,"bold"),bg="#eef2f7",fg="#102b50"); self.summary.pack(anchor="w",pady=12)
    def build_cashbook(self):
        bar=tk.Frame(self.cashbook,bg="#eef2f7");bar.pack(fill="x",pady=10)
        ttk.Button(bar,text="Kas Masuk",command=lambda:self.add_cash_entry("MASUK")).pack(side="left",padx=5)
        ttk.Button(bar,text="Kas Keluar",command=lambda:self.add_cash_entry("KELUAR")).pack(side="left",padx=5)
        ttk.Button(bar,text="Muat Ulang",command=self.refresh_cashbook).pack(side="left",padx=5)
        self.cash_tree=ttk.Treeview(self.cashbook,columns=("date","kind","desc","amount","ref"),show="headings")
        for c,h,w in zip(("date","kind","desc","amount","ref"),("Tanggal","Jenis","Keterangan","Nominal","Referensi"),(180,100,360,140,180)):
            self.cash_tree.heading(c,text=h);self.cash_tree.column(c,width=w)
        self.cash_tree.pack(fill="both",expand=True,pady=8)
        self.cash_summary=tk.Label(self.cashbook,text="",font=("Segoe UI",14,"bold"),bg="#eef2f7",fg="#102b50")
        self.cash_summary.pack(anchor="w",pady=10)
    def build_stock(self):
        bar=tk.Frame(self.stocktab,bg="#eef2f7");bar.pack(fill="x",pady=10)
        ttk.Button(bar,text="Posisi Stok",command=self.show_stock_position).pack(side="left",padx=4)
        ttk.Button(bar,text="Penyesuaian Stok",command=self.adjust_stock).pack(side="left",padx=4)
        ttk.Button(bar,text="Muat Mutasi",command=self.refresh_movements).pack(side="left",padx=4)
        ttk.Button(bar,text="Backup Database",command=self.backup_database).pack(side="left",padx=4)
        ttk.Button(bar,text="Restore Database",command=self.restore_database).pack(side="left",padx=4)
        self.movement_tree=ttk.Treeview(self.stocktab,columns=("date","code","name","kind","before","qty","after","note","ref"),show="headings")
        for c,h,w in zip(("date","code","name","kind","before","qty","after","note","ref"),("Tanggal","Kode","Barang","Jenis Mutasi","Stok Awal","Selisih","Stok Akhir","Keterangan","Referensi"),(155,90,190,115,80,75,80,170,145)):
            self.movement_tree.heading(c,text=h);self.movement_tree.column(c,width=w)
        self.movement_tree.pack(fill="both",expand=True,pady=8)
    def refresh_movements(self):
        if not hasattr(self,"movement_tree"):return
        for x in self.movement_tree.get_children():self.movement_tree.delete(x)
        with db() as c:
            rows=c.execute("""SELECT m.*,p.code,p.name FROM movements m
                LEFT JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT 1000""").fetchall()
        for r in rows:
            before=r["stock_before"] if "stock_before" in r.keys() else None
            after=r["stock_after"] if "stock_after" in r.keys() else None
            self.movement_tree.insert("","end",values=(r["created"],r["code"] or "",r["name"] or "",r["kind"],
                "" if before is None else before,r["qty"],"" if after is None else after,
                r["note"] or "",r["ref"] or ""))
    def show_stock_position(self):
        win=tk.Toplevel(self.root);win.title("Posisi Stok");win.geometry("850x520")
        tree=ttk.Treeview(win,columns=("code","name","group","stock","min","value"),show="headings")
        for c,h,w in zip(("code","name","group","stock","min","value"),("Kode","Nama Barang","Kelompok","Stok","Stok Minimum","Nilai Modal Stok"),(110,250,150,80,110,140)):
            tree.heading(c,text=h);tree.column(c,width=w)
        tree.pack(fill="both",expand=True)
        with db() as c:
            rows=c.execute("""SELECT p.code,p.name,g.name grp,p.stock,
                COALESCE(p.min_stock,0) min_stock,p.cost*p.stock stock_value
                FROM products p LEFT JOIN groups g ON g.id=p.group_id
                WHERE p.active=1 ORDER BY p.name""").fetchall()
        for r in rows:tree.insert("","end",values=(r["code"],r["name"],r["grp"] or "",r["stock"],r["min_stock"],f'{r["stock_value"]:,.0f}'))
    def adjust_stock(self):
        """Stock opname: compare physical count with system stock and save an auditable adjustment."""
        with db() as c:
            rows=c.execute(
                "SELECT id,code,name,barcode,stock FROM products WHERE active=1 ORDER BY name"
            ).fetchall()
        if not rows:
            messagebox.showinfo("Penyesuaian Stok","Belum ada barang aktif.")
            return

        win=tk.Toplevel(self.root)
        win.title("Penyesuaian Stok / Stok Opname")
        win.geometry("720x470")
        win.minsize(650,420)
        win.transient(self.root)
        win.grab_set()
        win.configure(bg="#eef2f7")

        tk.Label(win,text="PENYESUAIAN STOK",font=("Segoe UI",17,"bold"),
                 fg="#102b50",bg="#eef2f7").pack(anchor="w",padx=18,pady=(16,2))
        tk.Label(win,text="Pilih barang, hitung stok fisik, lalu simpan selisihnya.",
                 font=("Segoe UI",10),fg="#526276",bg="#eef2f7").pack(anchor="w",padx=18,pady=(0,12))

        body=tk.Frame(win,bg="white",padx=16,pady=14)
        body.pack(fill="both",expand=True,padx=16,pady=4)

        tk.Label(body,text="Cari barang (kode / barcode / nama)",bg="white",
                 fg="#25364b").grid(row=0,column=0,sticky="w")
        search_var=tk.StringVar()
        search_entry=ttk.Entry(body,textvariable=search_var,width=48)
        search_entry.grid(row=1,column=0,columnspan=2,sticky="ew",pady=(3,12))

        tk.Label(body,text="Barang",bg="white",fg="#25364b").grid(row=2,column=0,sticky="w")
        selected_var=tk.StringVar()
        product_combo=ttk.Combobox(body,textvariable=selected_var,state="readonly",width=55)
        product_combo.grid(row=3,column=0,columnspan=2,sticky="ew",pady=(3,12))

        system_var=tk.StringVar(value="-")
        physical_var=tk.StringVar()
        delta_var=tk.StringVar(value="-")
        tk.Label(body,text="Stok menurut sistem",bg="white",fg="#25364b").grid(row=4,column=0,sticky="w")
        tk.Label(body,text="Stok fisik hasil hitung",bg="white",fg="#25364b").grid(row=4,column=1,sticky="w")
        tk.Label(body,textvariable=system_var,font=("Segoe UI",15,"bold"),
                 fg="#102b50",bg="white").grid(row=5,column=0,sticky="w",pady=(3,12))
        physical_entry=ttk.Entry(body,textvariable=physical_var,width=20)
        physical_entry.grid(row=5,column=1,sticky="w",pady=(3,12))

        tk.Label(body,text="Selisih (+ bertambah / - berkurang)",bg="white",
                 fg="#25364b").grid(row=6,column=0,sticky="w")
        tk.Label(body,textvariable=delta_var,font=("Segoe UI",14,"bold"),
                 fg="#087443",bg="white").grid(row=7,column=0,sticky="w",pady=(3,12))

        tk.Label(body,text="Alasan / keterangan",bg="white",fg="#25364b").grid(row=8,column=0,sticky="w")
        note_var=tk.StringVar(value="Stok opname")
        note_entry=ttk.Entry(body,textvariable=note_var,width=55)
        note_entry.grid(row=9,column=0,columnspan=2,sticky="ew",pady=(3,4))

        body.columnconfigure(0,weight=1)
        body.columnconfigure(1,weight=1)

        filtered=list(rows)
        current=None
        def label_for(r):
            return f'{r["code"]} | {r["name"]} | Stok: {r["stock"]:g}'
        def refresh_choices(*_):
            nonlocal filtered
            q=search_var.get().strip().lower()
            filtered=[r for r in rows if q in str(r["code"]).lower()
                      or q in str(r["name"]).lower()
                      or q in str(r["barcode"] or "").lower()]
            product_combo["values"]=[label_for(r) for r in filtered]
            if filtered:
                product_combo.current(0)
                choose_product()
            else:
                selected_var.set("")
                system_var.set("-")
                delta_var.set("-")
        def choose_product(_event=None):
            nonlocal current
            idx=product_combo.current()
            if idx<0 or idx>=len(filtered):
                current=None
                return
            current=filtered[idx]
            system_var.set(f'{current["stock"]:g}')
            physical_var.set(f'{current["stock"]:g}')
            calculate_delta()
        def calculate_delta(*_):
            try:
                physical=float(physical_var.get().strip().replace(",","."))
                if physical<0: raise ValueError()
                base=float(current["stock"]) if current else 0
                delta=physical-base
                delta_var.set(f'{delta:+g}')
            except Exception:
                delta_var.set("Masukkan angka stok fisik yang valid")
        def save_adjustment():
            if current is None:
                messagebox.showwarning("Pilih barang","Pilih barang yang akan disesuaikan.",parent=win)
                return
            try:
                physical=float(physical_var.get().strip().replace(",","."))
                if physical<0: raise ValueError()
            except Exception:
                messagebox.showwarning("Stok tidak valid","Stok fisik harus berupa angka nol atau lebih.",parent=win)
                return
            note=note_var.get().strip()
            if not note:
                messagebox.showwarning("Keterangan wajib","Isi alasan penyesuaian stok.",parent=win)
                return
            try:
                with db() as c:
                    c.execute("BEGIN IMMEDIATE")
                    fresh=c.execute("SELECT stock,code,name FROM products WHERE id=? AND active=1",
                                    (current["id"],)).fetchone()
                    if fresh is None:
                        raise ValueError("Barang sudah tidak aktif atau tidak ditemukan.")
                    before=float(fresh["stock"] or 0)
                    delta=physical-before
                    if abs(delta)<0.0000001:
                        messagebox.showinfo("Tidak ada selisih","Stok fisik sama dengan stok sistem. Tidak ada perubahan.",parent=win)
                        c.rollback()
                        return
                    now=datetime.now().isoformat(timespec="seconds")
                    ref="OPNAME-"+datetime.now().strftime("%Y%m%d%H%M%S")
                    c.execute("UPDATE products SET stock=? WHERE id=?",(physical,current["id"]))
                    c.execute("""INSERT INTO movements
                        (created,product_id,kind,qty,note,ref,stock_before,stock_after)
                        VALUES(?,?,?,?,?,?,?,?)""",
                        (now,current["id"],"PENYESUAIAN",delta,note,ref,before,physical))
                    c.execute("INSERT INTO audit(created,action,detail) VALUES(?,?,?)",
                              (now,"PENYESUAIAN STOK",
                               f'{fresh["code"]} {fresh["name"]}: {before:g} -> {physical:g} (selisih {delta:+g}); {note}'))
                messagebox.showinfo("Berhasil",
                    f'Penyesuaian tersimpan.\nStok sistem: {before:g}\nStok fisik: {physical:g}\nSelisih: {delta:+g}',
                    parent=win)
                win.destroy()
                self.refresh_products()
                self.refresh_movements()
            except Exception as e:
                messagebox.showerror("Gagal menyimpan",str(e),parent=win)

        search_var.trace_add("write",refresh_choices)
        product_combo.bind("<<ComboboxSelected>>",choose_product)
        physical_var.trace_add("write",calculate_delta)
        buttons=tk.Frame(win,bg="#eef2f7")
        buttons.pack(fill="x",padx=16,pady=12)
        ttk.Button(buttons,text="TUTUP",command=win.destroy).pack(side="right",padx=(6,0))
        ttk.Button(buttons,text="SIMPAN PENYESUAIAN",command=save_adjustment).pack(side="right")
        refresh_choices()
        search_entry.focus_set()

    def backup_database(self):
        path=filedialog.asksaveasfilename(defaultextension=".db",initialfile="SeaMart_Backup.db",filetypes=[("Database SQLite","*.db")])
        if not path:return
        try:
            with db() as c:
                dest=sqlite3.connect(path)
                c.backup(dest);dest.close()
            messagebox.showinfo("Backup berhasil",f"Salinan database tersimpan:\\n{path}")
        except Exception as e:messagebox.showerror("Backup gagal",str(e))
    def restore_database(self):
        path=filedialog.askopenfilename(filetypes=[("Database SQLite","*.db")])
        if not path:return
        if os.path.abspath(path)==os.path.abspath(DB):
            messagebox.showwarning("Tidak bisa","Pilih file backup, bukan database yang sedang dipakai.");return
        if not messagebox.askyesno("Konfirmasi Restore","Restore akan mengganti seluruh data lokal saat ini. Buat backup terbaru dahulu. Lanjutkan?"):return
        try:
            test=sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro",uri=True)
            test.execute("PRAGMA schema_version").fetchone();test.close()
            shutil.copy2(path,DB)
            messagebox.showinfo("Restore berhasil","Database dipulihkan. Aplikasi akan ditutup; buka kembali SeaMart.")
            self.root.destroy()
        except Exception as e:messagebox.showerror("Restore gagal",str(e))

    def add_cash_entry(self,kind):
        desc=simpledialog.askstring("Kas "+kind.title(),"Keterangan:")
        if not desc or not desc.strip():return
        amount=simpledialog.askfloat("Kas "+kind.title(),"Nominal rupiah:",minvalue=0.01)
        if amount is None:return
        try:
            with db() as c:c.execute("INSERT INTO cash_entries(created,kind,description,amount,ref) VALUES(?,?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),kind,desc.strip(),amount,"MANUAL"))
            audit("KAS "+kind, f"{desc.strip()} Rp {amount:,.0f}");self.refresh_cashbook()
        except Exception as e:messagebox.showerror("Gagal",str(e))
    def refresh_cashbook(self):
        if not hasattr(self,"cash_tree"):return
        for x in self.cash_tree.get_children():self.cash_tree.delete(x)
        with db() as c:
            rows=c.execute("SELECT * FROM cash_entries ORDER BY id DESC").fetchall()
            inc=c.execute("SELECT COALESCE(SUM(amount),0) FROM cash_entries WHERE kind='MASUK'").fetchone()[0]
            out=c.execute("SELECT COALESCE(SUM(amount),0) FROM cash_entries WHERE kind='KELUAR'").fetchone()[0]
        for r in rows:self.cash_tree.insert("","end",iid=str(r["id"]),values=(r["created"],r["kind"],r["description"],f"{r['amount']:,.0f}",r["ref"] or ""))
        self.cash_summary.config(text=f"Kas masuk: Rp {inc:,.0f}    Kas keluar: Rp {out:,.0f}    Saldo kas manual: Rp {inc-out:,.0f}")
    def item_report_rows(self):
        with db() as c:
            return c.execute("""SELECT si.code,si.name,SUM(si.qty) qty,SUM(si.line_total) omzet,
                SUM(si.qty*(si.price)-si.discount) net,
                SUM(si.qty*(si.price-COALESCE(si.cost,0))-si.discount) gross_profit
                FROM sale_items si JOIN sales s ON s.id=si.sale_id
                LEFT JOIN products p ON p.id=si.product_id
                WHERE s.status='PROCESSED' GROUP BY si.code,si.name ORDER BY omzet DESC""").fetchall()
    def show_item_report(self):
        rows=self.item_report_rows()
        win=tk.Toplevel(self.root);win.title("Penjualan per Barang");win.geometry("900x520")
        tree=ttk.Treeview(win,columns=("code","name","qty","sales","profit"),show="headings")
        for c,h,w in zip(("code","name","qty","sales","profit"),("Kode","Nama Barang","Qty Terjual","Omzet","Estimasi Laba Kotor"),(120,300,100,150,170)):
            tree.heading(c,text=h);tree.column(c,width=w)
        tree.pack(fill="both",expand=True)
        for r in rows:tree.insert("","end",values=(r["code"],r["name"],r["qty"],f'{r["omzet"]:,.0f}',f'{r["gross_profit"]:,.0f}'))
    def export_xlsx(self):
        path=filedialog.asksaveasfilename(defaultextension=".xlsx",filetypes=[("Excel Workbook","*.xlsx")])
        if not path:return
        try:
            from openpyxl import Workbook
            wb=Workbook();ws=wb.active;ws.title="Penjualan per Barang"
            ws.append(["Kode","Nama Barang","Qty Terjual","Omzet","Estimasi Laba Kotor"])
            for r in self.item_report_rows():ws.append([r["code"],r["name"],r["qty"],r["omzet"],r["gross_profit"]])
            ws2=wb.create_sheet("Riwayat Transaksi")
            ws2.append(["Invoice","Tanggal","Pembayaran","Total","Status"])
            with db() as c: sales=c.execute("SELECT invoice,created,payment,total,status FROM sales ORDER BY id").fetchall()
            for r in sales:ws2.append(list(r))
            ws3=wb.create_sheet("Kas Masuk Keluar")
            ws3.append(["Tanggal","Jenis","Keterangan","Nominal","Referensi"])
            with db() as c: cash=c.execute("SELECT created,kind,description,amount,ref FROM cash_entries ORDER BY id").fetchall()
            for r in cash:ws3.append(list(r))
            wb.save(path);messagebox.showinfo("Ekspor Excel","Laporan berhasil disimpan.")
        except Exception as e:messagebox.showerror("Ekspor gagal",str(e))
    def export_pdf(self):
        path=filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF","*.pdf")])
        if not path:return
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4,landscape
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
            from reportlab.lib.styles import getSampleStyleSheet
            doc=SimpleDocTemplate(path,pagesize=landscape(A4));styles=getSampleStyleSheet()
            data=[["Kode","Nama Barang","Qty","Omzet","Estimasi Laba Kotor"]]
            for r in self.item_report_rows():data.append([r["code"],r["name"],str(r["qty"]),f'{r["omzet"]:,.0f}',f'{r["gross_profit"]:,.0f}'])
            if len(data)==1:data.append(["-","Belum ada penjualan","0","0","0"])
            table=Table(data,repeatRows=1,colWidths=[85,260,65,110,130])
            table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#102b50")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),("FONTSIZE",(0,0),(-1,-1),8),("PADDING",(0,0),(-1,-1),6)]))
            doc.build([Paragraph("SeaMart POS - Laporan Penjualan per Barang",styles["Title"]),Spacer(1,12),table])
            messagebox.showinfo("Ekspor PDF","Laporan PDF berhasil disimpan.")
        except Exception as e:messagebox.showerror("Ekspor gagal",str(e))
    def refresh_groups(self):
        with db() as c: self.groups=[r["name"] for r in c.execute("SELECT name FROM groups ORDER BY name")]
        self.group_combo["values"]=["Semua Kelompok"]+self.groups
    def refresh_products(self):
        for x in self.product_tree.get_children(): self.product_tree.delete(x)
        with db() as c:
            rows=c.execute("SELECT p.*,g.name grp FROM products p LEFT JOIN groups g ON g.id=p.group_id ORDER BY p.name").fetchall()
        for r in rows: self.product_tree.insert("", "end",iid=str(r["id"]),values=(r["code"],r["barcode"] or "",r["name"],r["grp"] or "",r["cost"],r["price"],r["stock"]))
    def add_product(self):
        q=self.search.get().strip()
        if not q:return
        with db() as c:
            rows=c.execute("SELECT * FROM products WHERE active=1 AND (code=? OR barcode=? OR name LIKE ?) ORDER BY CASE WHEN code=? OR barcode=? THEN 0 ELSE 1 END LIMIT 20",(q,q,"%"+q+"%",q,q)).fetchall()
        if not rows: messagebox.showwarning("Tidak ditemukan","Barang tidak ditemukan di Master Barang."); return
        if len(rows)>1:
            choice=simpledialog.askinteger("Pilih barang","Ditemukan beberapa barang. Masukkan nomor:\n"+"\n".join(f"{i+1}. {r['name']} ({r['code']})" for i,r in enumerate(rows)),minvalue=1,maxvalue=len(rows))
            if not choice:return
            p=rows[choice-1]
        else:p=rows[0]
        if p["stock"]<=0: messagebox.showwarning("Stok kosong","Stok barang kosong."); return
        found=next((x for x in self.cart if x["id"]==p["id"]),None)
        if found:
            if found["qty"]+1>found["stock"]:
                messagebox.showwarning("Stok tidak cukup",f'Stok tersedia {found["stock"]}');return
            found["qty"]+=1
        else:self.cart.append(dict(id=p["id"],code=p["code"],barcode=p["barcode"] or "",name=p["name"],qty=1,price=p["price"],discount=0,stock=p["stock"]))
        self.search.set(""); self.render_cart()
    def render_cart(self):
        for x in self.cart_tree.get_children():self.cart_tree.delete(x)
        for i,x in enumerate(self.cart):
            total=max(0,x["qty"]*x["price"]-x["discount"])
            self.cart_tree.insert("","end",iid=str(i),values=(x["code"],x["barcode"],x["name"],x["qty"],f"{x['price']:,.0f}",f"{x['discount']:,.0f}",f"{total:,.0f}"))
        self.total_label.config(text=f"TOTAL: Rp {self.cart_total():,.0f}")
    def cart_total(self):return sum(max(0,x["qty"]*x["price"]-x["discount"]) for x in self.cart)
    def selected_cart(self):
        s=self.cart_tree.selection()
        if not s:messagebox.showinfo("Pilih item","Pilih barang di keranjang.");return None
        return int(s[0])
    def change_qty(self):
        i=self.selected_cart()
        if i is None:return
        q=simpledialog.askfloat("Ubah Qty","Masukkan jumlah:",initialvalue=self.cart[i]["qty"],minvalue=0.001)
        if q is not None:
            if q>self.cart[i]["stock"]:messagebox.showwarning("Stok tidak cukup",f"Stok tersedia {self.cart[i]['stock']}");return
            self.cart[i]["qty"]=q;self.render_cart()
    def item_discount(self):
        i=self.selected_cart()
        if i is None:return
        d=simpledialog.askfloat("Diskon barang","Nominal diskon rupiah:",initialvalue=self.cart[i]["discount"],minvalue=0)
        if d is not None:self.cart[i]["discount"]=min(d,self.cart[i]["qty"]*self.cart[i]["price"]);self.render_cart()
    def remove_item(self):
        i=self.selected_cart()
        if i is not None:self.cart.pop(i);self.render_cart()
    def clear_cart(self):
        if self.cart and messagebox.askyesno("Konfirmasi","Kosongkan keranjang?"):self.cart=[];self.render_cart()
    def process_sale(self):
        if not self.cart:messagebox.showwarning("Kosong","Keranjang masih kosong.");return
        subtotal=sum(x["qty"]*x["price"] for x in self.cart)
        discount=sum(x["discount"] for x in self.cart)
        total=max(0,subtotal-discount); method=self.payment.get()
        try: received=float(self.received.get().replace(",","").replace(".","")) if method=="Tunai" else total
        except:messagebox.showerror("Input salah","Uang diterima harus angka.");return
        if received<total:messagebox.showwarning("Pembayaran kurang","Uang diterima kurang dari total.");return
        if not messagebox.askyesno("Konfirmasi pembayaran",f"Proses transaksi Rp {total:,.0f}?"):return
        now=datetime.now(); invoice="SM"+now.strftime("%Y%m%d%H%M%S%f")
        try:
            with db() as c:
                c.execute("INSERT INTO sales(invoice,created,payment,subtotal,discount,total,received,change_due,status) VALUES(?,?,?,?,?,?,?,?,?)",(invoice,now.isoformat(timespec="seconds"),method,subtotal,discount,total,received,received-total,"PROCESSED"))
                sid=c.execute("SELECT last_insert_rowid()").fetchone()[0]
                for x in self.cart:
                    current=c.execute("SELECT stock FROM products WHERE id=?",(x["id"],)).fetchone()
                    if not current or current["stock"]<x["qty"]:raise ValueError("Stok berubah/tidak cukup untuk "+x["name"])
                    line=x["qty"]*x["price"]-x["discount"]
                    c.execute("INSERT INTO sale_items(sale_id,product_id,code,barcode,name,qty,price,cost,discount,line_total) VALUES(?,?,?,?,?,?,?,?,?,?)",(sid,x["id"],x["code"],x["barcode"],x["name"],x["qty"],x["price"],p_cost:=c.execute("SELECT cost FROM products WHERE id=?",(x["id"],)).fetchone()["cost"],x["discount"],line))
                    c.execute("UPDATE products SET stock=stock-? WHERE id=?",(x["qty"],x["id"]))
                    c.execute("INSERT INTO movements(created,product_id,kind,qty,note,ref) VALUES(?,?,?,?,?,?)",(now.isoformat(timespec="seconds"),x["id"],"PENJUALAN",-x["qty"],"Penjualan",invoice))
            audit("PROSES",invoice)
            receipt_items=[dict(name=x["name"],qty=x["qty"],price=x["price"],discount=x["discount"],
                                line_total=x["qty"]*x["price"]-x["discount"]) for x in self.cart]
            self.cart=[];self.render_cart();self.refresh_products();self.refresh_sales()
            self.show_receipt(invoice,now,method,receipt_items,total,received,received-total)
        except Exception as e:messagebox.showerror("Gagal memproses",str(e))
    def show_receipt(self,invoice,created,method,items,subtotal,received,change):
        width=32
        def line(ch="-"): return ch*width
        def center(value): return str(value)[:width].center(width)
        def money(value): return f"{value:,.0f}".replace(",",".")
        lines=[center("SEAMART"),center("STRUK PEMBELIAN"),line(),
               f"No: {invoice}",created.strftime("%d-%m-%Y %H:%M"),
               f"Pembayaran: {method}",line()]
        for item in items:
            lines.append(item["name"][:width])
            lines.append(f'{item["qty"]:g} x {money(item["price"])}')
            if item["discount"]: lines.append(f'Diskon: -{money(item["discount"])}')
            lines.append(f'= Rp {money(item["line_total"])}')
        lines += [line(),f'TOTAL : Rp {money(subtotal)}']
        if method=="Tunai":
            lines += [f'DITERIMA: Rp {money(received)}',f'KEMBALI : Rp {money(change)}']
        lines += [line(),center("TERIMA KASIH"),center("SELAMAT BERBELANJA")]
        receipt="\\n".join(lines)+"\\n"
        win=tk.Toplevel(self.root);win.title("Preview Struk 58 mm");win.geometry("390x650")
        tk.Label(win,text="PREVIEW STRUK • 58 mm",font=("Segoe UI",11,"bold")).pack(pady=8)
        area=tk.Text(win,font=("Consolas",10),width=38,height=29,wrap="none")
        area.pack(fill="both",expand=True,padx=12,pady=8)
        area.insert("1.0",receipt);area.config(state="disabled")
        buttons=tk.Frame(win);buttons.pack(fill="x",padx=12,pady=10)
        def print_receipt():
            try:
                import tempfile
                fd,path=tempfile.mkstemp(prefix="SeaMart_Struk_",suffix=".txt")
                with os.fdopen(fd,"w",encoding="utf-8") as f:f.write(receipt)
                if sys.platform=="win32":
                    os.startfile(path,"print")
                    messagebox.showinfo("Cetak struk","Perintah cetak dikirim ke printer default Windows. Pastikan driver printer 58 mm sudah terpasang.")
                else: messagebox.showinfo("Cetak struk",f"File struk tersimpan: {path}")
            except Exception as e:
                messagebox.showerror("Gagal mencetak",f"Tidak dapat mengirim struk ke printer default Windows.\\n{e}")
        ttk.Button(buttons,text="CETAK STRUK",command=print_receipt).pack(side="left",expand=True,fill="x",padx=4)
        ttk.Button(buttons,text="TUTUP",command=win.destroy).pack(side="left",expand=True,fill="x",padx=4)

    def add_dialog(self):
        self.product_form()
    def product_form(self,row=None):
        win=tk.Toplevel(self.root);win.title("Master Barang");win.grab_set()
        fields={}
        labels=["Kode Barang","Barcode","Nama Barang","Kelompok","Harga Modal","Harga Jual","Stok","Stok Minimum"]
        vals=[row["code"] if row else "",row["barcode"] if row else "",row["name"] if row else "",row["grp"] if row else self.groups[0],str(row["cost"]) if row else "0",str(row["price"]) if row else "0",str(row["stock"]) if row else "0",str(row["min_stock"]) if row else "0"]
        for i,(lab,val) in enumerate(zip(labels,vals)):
            tk.Label(win,text=lab).grid(row=i,column=0,sticky="w",padx=10,pady=5)
            if lab=="Kelompok":
                v=tk.StringVar(value=val);w=ttk.Combobox(win,textvariable=v,values=self.groups,state="readonly",width=30)
            else:v=tk.StringVar(value=val);w=ttk.Entry(win,textvariable=v,width=33)
            w.grid(row=i,column=1,padx=10,pady=5);fields[lab]=v
        def save():
            try:
                code=fields["Kode Barang"].get().strip();name=fields["Nama Barang"].get().strip()
                if not code or not name:raise ValueError("Kode dan nama barang wajib diisi.")
                with db() as c:
                    gid=c.execute("SELECT id FROM groups WHERE name=?",(fields["Kelompok"].get(),)).fetchone()[0]
                    data=(code,fields["Barcode"].get().strip() or None,name,gid,float(fields["Harga Modal"].get() or 0),float(fields["Harga Jual"].get() or 0),float(fields["Stok"].get() or 0),float(fields["Stok Minimum"].get() or 0))
                    if row:c.execute("UPDATE products SET code=?,barcode=?,name=?,group_id=?,cost=?,price=?,stock=?,min_stock=? WHERE id=?",(*data,row["id"]))
                    else:c.execute("INSERT INTO products(code,barcode,name,group_id,cost,price,stock,min_stock) VALUES(?,?,?,?,?,?,?,?)",data)
                audit("SAVE MASTER",code);win.destroy();self.refresh_products()
            except Exception as e:messagebox.showerror("Tidak tersimpan",str(e))
        ttk.Button(win,text="SAVE",command=save).grid(row=8,column=0,pady=10)
        ttk.Button(win,text="BATAL",command=win.destroy).grid(row=8,column=1,pady=10)
    def edit_product(self):
        s=self.product_tree.selection()
        if not s:messagebox.showinfo("Pilih barang","Pilih barang yang akan diubah.");return
        with db() as c:r=c.execute("SELECT p.*,g.name grp FROM products p LEFT JOIN groups g ON g.id=p.group_id WHERE p.id=?",(int(s[0]),)).fetchone()
        self.product_form(r)
    def delete_product(self):
        s=self.product_tree.selection()
        if not s:return
        if messagebox.askyesno("Hapus","Nonaktifkan barang ini?"):
            with db() as c:c.execute("UPDATE products SET active=0 WHERE id=?",(int(s[0]),))
            audit("NONAKTIFKAN BARANG",s[0]);self.refresh_products()
    def add_group(self):
        n=simpledialog.askstring("Kelompok Barang","Nama kelompok:")
        if n:
            try:
                with db() as c:c.execute("INSERT INTO groups(name) VALUES(?)",(n.strip(),))
                self.refresh_groups()
            except Exception as e:messagebox.showerror("Gagal",str(e))
    def import_csv(self):
        path=filedialog.askopenfilename(filetypes=[("CSV","*.csv")])
        if not path:return
        fallback_group=simpledialog.askstring(
            "Kelompok Barang",
            "Kelompok cadangan jika kolom Grup Produk kosong:",
            initialvalue=self.groups[0] if self.groups else "Lain-lain")
        if not fallback_group or not fallback_group.strip():return
        try:
            def num(v):
                v=(v or "").strip().replace("Rp","").replace(" ","")
                if not v:return 0.0
                if "," in v and "." in v:v=v.replace(".","").replace(",",".")
                elif "," in v:v=v.replace(",",".")
                elif v.count(".")>1:v=v.replace(".","")
                return float(v)
            with open(path,"r",encoding="utf-8-sig",newline="") as f:
                sample=f.read(4096);f.seek(0)
                try:dialect=csv.Sniffer().sniff(sample,delimiters=",;\\t")
                except csv.Error:dialect=csv.excel
                reader=csv.DictReader(f,dialect=dialect)
                headers={h.strip().lower():h for h in (reader.fieldnames or []) if h}
                def get(row,*keys):
                    for k in keys:
                        if k in headers:return (row.get(headers[k]) or "").strip()
                    return ""
                count=skip=0
                with db() as c:
                    for r in reader:
                        code=get(r,"kode produk","kode barang","kode","code","item code")
                        barcode=get(r,"barcode")
                        name=get(r,"produk","nama barang","nama","name","product")
                        cost=get(r,"harga pokok","harga modal","modal","cost")
                        price=get(r,"harga jual","price")
                        stock=get(r,"stok","stock")
                        row_group=get(r,"grup produk","kelompok","kategori","group","category") or fallback_group.strip()
                        if not code or not name:
                            skip+=1
                            continue
                        c.execute("INSERT OR IGNORE INTO groups(name) VALUES(?)",(row_group,))
                        gid=c.execute("SELECT id FROM groups WHERE name=?",(row_group,)).fetchone()["id"]
                        c.execute("""INSERT INTO products(code,barcode,name,group_id,cost,price,stock)
                            VALUES(?,?,?,?,?,?,?)
                            ON CONFLICT(code) DO UPDATE SET barcode=excluded.barcode,
                            name=excluded.name,group_id=excluded.group_id,cost=excluded.cost,
                            price=excluded.price,stock=excluded.stock""",
                            (code,barcode or None,name,gid,num(cost),num(price),num(stock)))
                        count+=1
            audit("IMPOR CSV",f"{count} data, {skip} dilewati")
            self.refresh_products();self.refresh_groups()
            messagebox.showinfo("Impor selesai",
                f"Berhasil diproses: {count}\\nDilewati: {skip}\\nKelompok mengikuti kolom Grup Produk; kelompok kosong memakai: {fallback_group.strip()}")
        except Exception as e:
            messagebox.showerror("Impor gagal",str(e))
    def export_products(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV Excel","*.csv")])
        if not path:return
        with db() as c:rows=c.execute("SELECT p.code,p.barcode,p.name,g.name kelompok,p.cost,p.price,p.stock FROM products p LEFT JOIN groups g ON g.id=p.group_id WHERE p.active=1").fetchall()
        with open(path,"w",encoding="utf-8-sig",newline="") as f:
            w=csv.writer(f);w.writerow(["kode barang","barcode","nama barang","kelompok","harga modal","harga jual","stok"]);w.writerows([tuple(r) for r in rows])
        messagebox.showinfo("Ekspor",f"File tersimpan:\n{path}")
    def refresh_sales(self):
        if not hasattr(self,"sales_tree"):return
        for x in self.sales_tree.get_children():self.sales_tree.delete(x)
        with db() as c:
            rows=c.execute("SELECT * FROM sales ORDER BY id DESC").fetchall()
            total=c.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE status='PROCESSED'").fetchone()[0]
        for r in rows:self.sales_tree.insert("","end",iid=str(r["id"]),values=(r["invoice"],r["created"],r["payment"],f"{r['total']:,.0f}",r["status"]))
        self.summary.config(text=f"Total omzet transaksi terproses: Rp {total:,.0f}")
    def export_sales(self):
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV Excel","*.csv")])
        if not path:return
        with db() as c:rows=c.execute("SELECT invoice,created,payment,subtotal,discount,total,received,change_due,status FROM sales ORDER BY id").fetchall()
        with open(path,"w",encoding="utf-8-sig",newline="") as f:
            w=csv.writer(f);w.writerow(["no transaksi","tanggal","pembayaran","subtotal","diskon","total","diterima","kembalian","status"]);w.writerows([tuple(r) for r in rows])
        messagebox.showinfo("Ekspor",f"File tersimpan:\n{path}")
    def unprocess(self):
        s=self.sales_tree.selection()
        if not s:messagebox.showinfo("Pilih transaksi","Pilih transaksi yang akan di-unproses.");return
        sid=int(s[0])
        if not messagebox.askyesno("UNPROSES","Batalkan transaksi ini dan kembalikan stok? Tindakan tercatat di audit."):return
        try:
            with db() as c:
                sale=c.execute("SELECT * FROM sales WHERE id=?",(sid,)).fetchone()
                if sale["status"]!="PROCESSED":raise ValueError("Transaksi sudah tidak berstatus PROCESSED.")
                items=c.execute("SELECT * FROM sale_items WHERE sale_id=?",(sid,)).fetchall()
                for x in items:
                    c.execute("UPDATE products SET stock=stock+? WHERE id=?",(x["qty"],x["product_id"]))
                    c.execute("INSERT INTO movements(created,product_id,kind,qty,note,ref) VALUES(?,?,?,?,?,?)",(datetime.now().isoformat(timespec="seconds"),x["product_id"],"UNPROSES",x["qty"],"Pembatalan transaksi",sale["invoice"]))
                c.execute("UPDATE sales SET status='UNPROCESSED' WHERE id=?",(sid,))
            audit("UNPROSES",sale["invoice"]);self.refresh_sales();self.refresh_products();self.refresh_movements()
            messagebox.showinfo("Berhasil","Transaksi di-unproses dan stok dikembalikan.")
        except Exception as e:messagebox.showerror("Gagal",str(e))

if __name__=="__main__":
    init()
    root=tk.Tk()
    app=SeaMart(root)
    root.mainloop()
