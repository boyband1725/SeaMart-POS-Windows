SEAMART POS V15 - SOURCE WINDOWS 10/11

ISI PAKET
- seamart.py: aplikasi desktop Python/Tkinter + SQLite.
- requirements.txt: pustaka laporan.
- BUAT_EXE_DI_WINDOWS.bat: build EXE lokal di Windows.
- .github/workflows/build-windows-exe.yml: contoh workflow build Windows di GitHub Actions.
- test_seamart_db.py: uji database dan penyesuaian stok.

BUILD DI WINDOWS
1. Ekstrak seluruh isi ZIP ke satu folder di PC Windows 10/11.
2. Pasang Python 3.12 (64-bit) dari python.org dan centang Add Python to PATH.
3. Jalankan BUAT_EXE_DI_WINDOWS.bat.
4. Jika berhasil, hasilnya dist\SeaMartPOSV15.exe.

LOKASI DATA
Database disimpan terpisah dari EXE:
- Windows: %LOCALAPPDATA%\SeaMartPOS\seamart.db
- Sistem lain untuk pengujian: ~/.seamartpos/seamart.db
Ini membuat database tetap dapat ditulis walau EXE ditempatkan di Program Files.

UJI OTOMATIS DATABASE
Jalankan: python -m unittest -v test_seamart_db.py
Uji ini mencakup pembuatan skema baru, migrasi skema V15 lama, dan integritas transaksi penyesuaian stok.

STATUS DAN BATASAN
Paket ini masih SOURCE, bukan installer atau EXE. Uji otomatis database bukan pengganti uji UI di Windows.
Sebelum operasional, lakukan uji kasir/transaksi, impor CSV data toko, backup-restore, laporan, dan printer thermal 58mm.
Printer Bluetooth belum diverifikasi sebagai cetak ESC/POS native; fungsi cetak yang ada perlu diuji pada printer target.
Selalu backup database sebelum uji impor massal atau stok opname pertama.
