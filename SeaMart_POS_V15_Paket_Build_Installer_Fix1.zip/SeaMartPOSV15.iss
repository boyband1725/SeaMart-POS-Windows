#define MyAppName "SeaMart POS V15"
#define MyAppVersion "15.0.0"
#define MyAppPublisher "SeaMart"
#define MyAppExeName "SeaMartPOSV15.exe"

[Setup]
AppId={{B9B2AB10-0D6C-4F71-9A5B-7F4D2B4D15A0}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\SeaMart POS V15
DefaultGroupName=SeaMart POS V15
OutputDir=Output
OutputBaseFilename=SeaMartPOSV15-Setup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
Uninstallable=yes
; Do not remove the user's database when uninstalling/upgrading.

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\SeaMart POS V15"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\SeaMart POS V15"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Jalankan SeaMart POS V15"; Flags: postinstall nowait skipifsilent
