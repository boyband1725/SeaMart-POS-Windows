@echo off
setlocal
cd /d "%~dp0"
title SeaMart POS V15 - Build Windows
echo ============================================
echo       SEAMART POS V15 - BUILD WINDOWS
echo ============================================
python --version
if errorlevel 1 (
  echo Python 3.12 64-bit belum terpasang atau belum masuk PATH.
  pause
  exit /b 1
)
echo.
echo [1/5] Memasang dependensi...
python -m pip install --upgrade pip
if errorlevel 1 goto failed
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo [2/5] Menjalankan tes database...
python -m unittest -v test_seamart_db.py
if errorlevel 1 goto failed
echo.
echo [3/5] Memeriksa sintaks...
python -m py_compile seamart.py
if errorlevel 1 goto failed
echo.
echo [4/5] Membuat EXE...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name SeaMartPOSV15 seamart.py
if errorlevel 1 goto failed
if not exist "dist\SeaMartPOSV15.exe" goto failed
echo.
echo [5/5] Memeriksa paket installer...
where ISCC.exe >nul 2>&1
if not errorlevel 1 (
  ISCC.exe SeaMartPOSV15.iss
  if errorlevel 1 goto failed
  echo Installer dibuat di folder Output.
) else (
  echo Inno Setup tidak ditemukan. EXE portable sudah tersedia.
  echo Untuk membuat Setup.exe, pasang Inno Setup lalu jalankan file ini lagi.
)
echo.
echo BERHASIL. Periksa folder dist dan Output.
pause
exit /b 0
:failed
echo.
echo BUILD GAGAL. Baca pesan error di atas; jangan gunakan hasil build yang tidak lengkap.
pause
exit /b 1
