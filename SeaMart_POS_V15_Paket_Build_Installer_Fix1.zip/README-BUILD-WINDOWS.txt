SEAMART POS V15 - PAKET BUILD WINDOWS

Status paket: SOURCE + skrip build. BUKAN installer siap pakai.

Membuat EXE di Windows 10/11:
1. Ekstrak seluruh ZIP ke folder di PC Windows.
2. Instal Python 3.12 64-bit dan centang "Add Python to PATH".
3. (Opsional untuk Setup.exe) Instal Inno Setup 6.
4. Klik dua kali BUAT_EXE_DI_WINDOWS.bat.
5. Skrip menjalankan tes database, pemeriksaan sintaks, lalu membuat dist\SeaMartPOSV15.exe.
6. Jika Inno Setup terpasang, skrip juga membuat Output\SeaMartPOSV15-Setup.exe.

Data database berada di %LOCALAPPDATA%\SeaMartPOS\seamart.db dan tidak disimpan di folder Program Files.
Installer tidak menghapus database saat aplikasi di-uninstall.

PENTING:
- Tes database bukan pengganti pengujian UI dan transaksi end-to-end.
- Printer thermal Bluetooth 58 mm belum tervalidasi pada perangkat fisik.
- Jangan gunakan untuk transaksi nyata sebelum uji master barang, impor CSV, pembayaran, stok, laporan, backup/restore, dan printer.
